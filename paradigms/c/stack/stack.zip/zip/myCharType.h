/*
 * Dr. Vineyard
 * CS231 all sections
 * int myCharType.h
 */

typedef char dataType;

void dataPrint(dataType);
