Dominic Woodruff

Depending on the program the stackADT.h file needs to be modified
lines 3-5 are what datatype the stack uses

myChartype.h for palindrome.c, myDoubleType.h for postfix.c

the programs arguments are a text input file and a text output file.
(ex: ./a.out in.txt out.txt)

compiled via "gcc [program_name] stack.c"
