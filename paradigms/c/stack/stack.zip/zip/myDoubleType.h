//Dominic Woodruff

typedef double dataType;

void dataPrint(dataType);