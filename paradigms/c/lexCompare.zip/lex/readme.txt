lex uses in.txt, compare is piped into as shown in the pdf, there is a bug
with output on the compare.c so all will be listed as not in the dictionary
