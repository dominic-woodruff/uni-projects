//Dominic Woodruff

#include <stdio.h>
#include <ctype.h>
#include <string.h>


//Checks if a word is in the dictionary
int findword(int argc, char * path, char * target){
    char dictionary[255]; 
    FILE * input_file;
    input_file = fopen(path, "r");
    int found = 0;
    char string[255]; 
    char key[strlen(target)]; 
    strcpy(key, target);
    for(int i = 0; key[i]; i++){
        key[i] = tolower(key[i]);
    }
    while(fgets(string, 255, input_file) != NULL){
        found = strcmp(key, string);
        if(found == 0){
            printf("%s is in the dictionary.\n", target);
            return 1;
        }
    }
    printf("%s is not in the dictionary\n", target);
    return 0;
}

//loops through argc and checks if every argument after the output file is in the dictionary
int main(int argc, char * argv[]){
    int count = 3;
    char word[64];
    int isWord;
    FILE * output_file;
    output_file = fopen("output.txt", "w");
    char *output;
    

    while(count < argc){
        strcpy(word, argv[count]);
        isWord = findword(argc, argv[1], word);
        count++;
        if(isWord){
            output = strcat(word, " is in the dictionary\n");
            fputs(output, output_file);
        }
        else{
            output = strcat(word, " is not in the dictionary\n");
            fputs(output, output_file);
        }
    }
}
